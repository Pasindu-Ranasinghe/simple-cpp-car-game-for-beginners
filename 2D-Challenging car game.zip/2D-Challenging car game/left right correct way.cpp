#include <iostream>
#include <conio.h>
#include <stdlib.h>
#include <windows.h>
#include <cstring.h>

bool getInput(char *c); // Program Loop
int main(void){
char y = ' ';
char x;
char m;
string s;
int t=20;
int n=1;
while (y != 'q')
	{ 		while (!getInput(&y))
      		{ cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<s;

Sleep(t);
n=n+1 ;
system("CLS");
           			// Update your timer here
            	}
               // Update Program Logic Here
            if(y=='a'){
                 s="###";

               }
               if(y=='d'){
						s="    ###";

               }
               	} 	cout << "You Pressed q, End Of Program" << endl;
                  	return 0; }
                     // Get Input
                     bool getInput(char *c)
                     { if (kbhit())
                     { *c = getch();
                      return true; // Key Was Hit
                      }
                      	return false; // No keys were pressed
                        }