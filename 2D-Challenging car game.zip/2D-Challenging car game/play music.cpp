#include <iostream.h>
#include <conio.h>
#include <windows.h>


int main(){
PlaySound(TEXT("AAA.wav"),NULL,SND_FILENAME);


return 0;
}
