#include <iostream.h>
#include <conio.h>
#include <stdlib.h>
int main(){
char x= ' ';
int n=1;
while(n<200){
x=_getch();

if (x=='a'){
system("CLS");
cout<<"*         *"<<endl;
cout<<"*         *"<<endl;
cout<<"*         *"<<endl;
cout<<"*         *"<<endl;
cout<<"*         *"<<endl;
cout<<"*         *"<<endl;
cout<<"*         *"<<endl;
cout<<"* ##      *"<<endl;
cout<<"*####     *"<<endl;
cout<<"* ##      *"<<endl;




}

if(x=='d'){
system("CLS");
cout<<"*         *"<<endl;
cout<<"*         *"<<endl;
cout<<"*         *"<<endl;
cout<<"*         *"<<endl;
cout<<"*         *"<<endl;
cout<<"*         *"<<endl;
cout<<"*         *"<<endl;
cout<<"*      ## *"<<endl;
cout<<"*     ####*"<<endl;
cout<<"*      ## *"<<endl;


}

n=n+1;
    }


getch();
}