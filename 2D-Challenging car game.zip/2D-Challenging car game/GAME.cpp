#include <iostream.h>
#include <conio.h>
#include <stdlib.h>
#include <windows.h>
#include <cstring.h>
#include <time.h>
int song(){
PlaySound(TEXT("AAA.wav"),NULL,SND_FILENAME);


return 0;
}
int song1(){
PlaySound(TEXT("CCC.wav"),NULL,SND_FILENAME);


return 0;
}
int song2(){
PlaySound(TEXT("BBB.wav"),NULL,SND_FILENAME);


return 0;
}
int song3(){
PlaySound(TEXT("DDD.wav"),NULL,SND_FILENAME);


return 0;
}
bool getInput(char *c);
int main(void){
int w=1;
while(w>0){
srand ( time(NULL));
string x="#";
string d="###";
//char t=' ';
char g = ' ';
int n=1;
int cc=2000;
int h;
char nk;
char nl;
char nm;
int u=1;
int t=1000;
string m;
string q;
//int m=0;
int y=300;
int z=6000;
int kr;
int count=0;

cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<"                  *----------------------------------------*"<<endl;
cout<<"                  |                                        |"<<endl;
cout<<"                  |	        GROUP NO 2 PRESENTS		  	   |"<<endl;
cout<<"                  |             FINAL PROJECT              |"<<endl;
cout<<"                  |                 C++                    |"<<endl;
cout<<"                  |                                        |"<<endl;
cout<<"                  |   [ASANGI , UDARA , DINITH , PASINDU]  |"<<endl;
cout<<"                  |                                        |"<<endl;
cout<<"                  *----------------------------------------*"<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<"        Copyright � 2018 2D Challenging(Group 2). All Rights Reserved.";

song1();
Sleep(1000);
//song1();
system("CLS");


while(u>0){


cout<<"                            2D CHALLENING"<<endl;
cout<<"                             CAR RACING"<<endl;
cout<<endl;
cout<<"                       1.CONTROLS"<<endl;
cout<<endl;
cout<<"                       2.CREDITS "<<endl;
cout<<endl;
cout<<"                       3.ENTER THE RACE"<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<"whts is your next step press the number"<<endl;
cin>>nk;

if(nk=='1'){
system("CLS");
cout<<"* This is a brick car game in a 2D space."<<endl;
cout<<"* You car in located at the bottom of the console."<<endl;
cout<<"* Your oppositions come from top to bottom in two ways."<<endl;
cout<<"* You have to control your car to left and right"<<endl;
cout<<"* To Turn left PRESS(a) and Turn to right PRESS(d)"<<endl;
cout<<"* According to the time opposisiton cars increase their speed"<<endl;
cout<<"* you have to be safe with those two keys"<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
song3();
cout<<"PRESS 0 for back"<<endl;
cin>>nl;
if(nl==0){u=1;}

}
if(nk=='2'){
system("CLS");
cout<<"As the final group project of Nenasala C++ course,"<<endl;
song2();
Sleep(cc);
cout<<"we bilt up this car game with master's knowledge and internet knowledge"<<endl;
song2();
Sleep(cc);
cout<<"We did this as group 2(ASANGI,UDARA,DINITH,PASINDU)"<<endl;
song2();
Sleep(cc);
cout<<"Because of our sir(AYYA),we could finish our project correctly  "<<endl;
song2();
Sleep(cc);
cout<<"All credits goes to him,we are thnkful for him for keeping us a position like this"<<endl;
song1();
Sleep(2*cc);
cout<<"And also members did their job pointly,THNKUUU"<<endl;
song2();
Sleep(cc);
cout<<"Enjoy the game"<<endl;
song2();

Sleep(cc);
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<"PRESS 0 for back"<<endl;
cin>>nl;
if(nl=='0'){u=1;}
}
if(nk=='3'){
system("CLS");
u=-u;
}

cout<<q<<endl;
cout<<m<<endl;
cout<<q<<endl;
cout<<m;
system("CLS");
u=u+1;
       }

while (g!='0'){

while (!getInput(&g)){

if(n%60==0){
y=y-10;
if(y==10){
system("CLS");
song1();
cout<<"YOU WON THE GAME!!!"<<endl;
cout<<endl;
cout<<" PRESS 0"<<endl;
system("CLS");

}
}
if(n%200==0 && n>0 && cout>0){
system("CLS");
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<"    LEVEL "<<(n/200)<<" COMPLETED!!!!"<< endl;
cout<<endl;
cout<<endl;
for(int i=3;i>-1;i=i-1){
system("CLS");
cout<<"NEXT LEVEL STARTS WITHIN "<<(i)<<" SECONDS";
Sleep(1000);
}
system("CLS");
}
if(n%20==0 && count==0){

system("CLS");
cout<<"  TO SHOW YOUR VEHICLE PRESS a or d while console is running "<<endl;
cout<<endl;

cout<<endl;
Sleep(3000);
cout<<"When you pressed a or d, the score is being increased from 0 " ;
Sleep(3000);

}
//if(n==2){cout<<"Press a or d to watch your vehicle"<<endl;
//Sleep(3000);
//}
if(n%20==1){
 const string f[2]={"###","    ###"};
int RandIndex = rand() %2;
d=f[RandIndex];
if(d=="    ###") {x="    #";}
if(d=="###"){x="#";}

cout<<' '<<x<<' '<<endl;
cout<<d<<endl;
cout<<' '<<x<<' '<<endl;
cout<<d<<"|"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<"               SCORE:"<<n<<endl;

cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;

cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<q<<endl;
cout<<m<<endl;
cout<<q<<endl;
cout<<m;



Sleep(y);
system("CLS");


}
if(n%20==2){
cout<<"   |"<<endl;
cout<<' '<<x<<endl;
cout<<d<<endl;
cout<<' '<<x<<endl;
cout<<d<<endl;

cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<"               SCORE:"<<n<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;

cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<q<<endl;
cout<<m<<endl;
cout<<q<<endl;
cout<<m<<endl;
Sleep(y);
system("CLS");

}
if(n%20==3){
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<' '<<x<<endl;
cout<<d<<endl;
cout<<' '<<x<<endl;
cout<<d<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<"               SCORE:"<<n<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<q<<endl;
cout<<m<<endl;
cout<<q<<endl;
cout<<m;
Sleep(y);
system("CLS");

}

if(n%20==4){
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<' '<<x<<endl;
cout<<d<<endl;
cout<<' '<<x<<endl;
cout<<d<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<"               SCORE:"<<n<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<q<<endl;
cout<<m<<endl;
cout<<q<<endl;
cout<<m;
Sleep(y);
system("CLS");
}

if(n%20==5){
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<' '<<x<<endl;
cout<<d<<endl;
cout<<' '<<x<<endl;
cout<<d<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<"               SCORE:"<<n<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<q<<endl;
cout<<m<<endl;
cout<<q<<endl;
cout<<m;
Sleep(y);
system("CLS");

}
if(n%20==6){
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<' '<<x<<endl;
cout<<d<<endl;
cout<<' '<<x<<endl;
cout<<d<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<"               SCORE:"<<n<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<q<<endl;
cout<<m<<endl;
cout<<q<<endl;
cout<<m;
Sleep(y);
system("CLS");

}
if(n%20==7){
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<' '<<x<<endl;
cout<<d<<endl;
cout<<' '<<x<<endl;
cout<<d<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<"               SCORE:"<<n<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<q<<endl;
cout<<m<<endl;
cout<<q<<endl;
cout<<m;
Sleep(y);
system("CLS");

}
if(n%20==8){
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<' '<<x<<endl;
cout<<d<<endl;
cout<<' '<<x<<endl;
cout<<d<<endl;
cout<<"   |"<<"               SCORE:"<<n<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<q<<endl;
cout<<m<<endl;
cout<<q<<endl;
cout<<m;
Sleep(y);
system("CLS");

}
if(n%20==9){
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<' '<<x<<endl;
cout<<d<<endl;
cout<<' '<<x<<endl;
cout<<d;
if(d=="    ###"){cout<<"            SCORE:"<<n<<endl;}
if(d=="###"){    cout<<"                SCORE:"<<n<<endl;}
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<q<<endl;
cout<<m<<endl;
cout<<q<<endl;
cout<<m;
Sleep(y);
system("CLS");

}
if(n%20==10){
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<' '<<x<<endl;
cout<<d<<endl;
cout<<' '<<x;
if(d=="    ###"){cout<<"            SCORE:"<<n<<endl;}
if(d=="###"){    cout<<"                SCORE:"<<n<<endl;}
cout<<d<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<q<<endl;
cout<<m<<endl;
cout<<q<<endl;
cout<<m;
Sleep(y);
system("CLS");

}
if(n%20==11){
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<' '<<x<<endl;
cout<<d;
if(d=="    ###"){cout<<"           SCORE:"<<n<<endl;}
if(d=="###"){cout<<"               SCORE:"<<n<<endl;}
cout<<' '<<x<<endl;
cout<<d<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<q<<endl;
cout<<m<<endl;
cout<<q<<endl;
cout<<m;
Sleep(y);
system("CLS");

}
if(n%20==12){
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<' '<<x;
if(d=="    ###"){cout<<"            SCORE:"<<n<<endl;}
if(d=="###"){cout<<"                SCORE:"<<n<<endl;}
cout<<d<<endl;
cout<<' '<<x<<endl;
cout<<d<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<q<<endl;
cout<<m<<endl;
cout<<q<<endl;
cout<<m;
Sleep(y);
system("CLS");

}
if(n%20==13){
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<"               SCORE:"<<n<<endl;
cout<<' '<<x<<endl;
cout<<d<<endl;
cout<<' '<<x<<endl;
cout<<d<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<q<<endl;
cout<<m<<endl;
cout<<q<<endl;
cout<<m;
Sleep(y);
system("CLS");

}
if(n%20==14){

cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<"               SCORE:"<<n<<endl;
cout<<"   |"<<endl;
cout<<' '<<x<<endl;
cout<<d<<endl;
cout<<' '<<x<<endl;
cout<<d<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<q<<endl;
cout<<m<<endl;
cout<<q<<endl;
cout<<m;
Sleep(y);
system("CLS");

}
if(n%20==15){


cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<"               SCORE:"<<n<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<' '<<x<<endl;
cout<<d<<endl;
cout<<' '<<x<<endl;
cout<<d<<endl;
cout<<"   |"<<endl;
cout<<q<<endl;
cout<<m<<endl;
cout<<q<<endl;
cout<<m;
Sleep(y);
system("CLS");

}
if(n%20==16){

cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<"               SCORE:"<<n<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<' '<<x<<endl;
cout<<d<<endl;
cout<<' '<<x<<endl;
cout<<d<<endl;
cout<<q<<endl;
cout<<m<<endl;
cout<<q<<endl;
cout<<m;
Sleep(y);
if(d=="###" && q==" #"){
system("CLS");
cout<<"                  ________________" <<endl;
cout<<"                  Your Score is :" <<n<<endl;
cout<<"                  ________________"<<endl;
cout<<endl;
cout<<"                !!!!!GAME OVER!!!!!"<<endl;

song();

cout<<" PRESS 0"<<endl;
Sleep(z);
}

if(d=="    ###" && q=="     #"){
system("CLS");
cout<<"                  ________________" <<endl;
cout<<"                  Your Score is :" <<n<<endl;
cout<<"                  ________________"<<endl;
cout<<endl;
cout<<"                !!!!!GAME OVER!!!!!"<<endl;

song();
cout<<" PRESS 0"<<endl;
Sleep(z);
}
system("CLS");

}

if(n%20==17){


cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<"               SCORE:"<<n<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<' '<<x<<endl;
cout<<d<<endl;
cout<<' '<<x<<endl;


cout<<q<<endl;
cout<<m<<endl;
cout<<q<<endl;
cout<<m;
Sleep(y);
if(d=="###" && q==" #"){

system("CLS");
cout<<"                  ________________"<<endl ;
cout<<"                  Your Score is :" <<n<<endl;
cout<<"                  ________________"<<endl;
cout<<endl;
cout<<"                !!!!!GAME OVER!!!!!"<<endl;

song();
cout<<" PRESS 0"<<endl;
Sleep(z);
}

if(d=="    ###" && q=="     #"){
system("CLS");
cout<<"                  ________________"<<endl ;
cout<<"                  Your Score is :" <<n<<endl;
cout<<"                  ________________"<<endl;
cout<<endl;
cout<<"                !!!!!GAME OVER!!!!!"<<endl;

song();
cout<<" PRESS 0"<<endl;
Sleep(z);
}
system("CLS");

}

if(n%20==18){


cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<"               SCORE:"<<n<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<' '<<x<<endl;
cout<<d<<endl;
cout<<q<<endl;
cout<<m<<endl;
cout<<q<<endl;
cout<<m;
Sleep(y);
if(d=="###" && q==" #"){
system("CLS");
cout<<"                  ________________"<<endl ;
cout<<"                  Your Score is :" <<n<<endl;
cout<<"                  ________________"<<endl;
cout<<endl;
cout<<"                !!!!!GAME OVER!!!!!"<<endl;

song();
cout<<" PRESS 0"<<endl;
Sleep(z);
}

if(d=="    ###" && q=="     #"){
system("CLS");
cout<<"                  ________________"<<endl ;
cout<<"                  Your Score is :" <<n<<endl;
cout<<"                  ________________"<<endl;
cout<<endl;
cout<<"                !!!!!GAME OVER!!!!!"<<endl;

song();

cout<<" PRESS 0"<<endl;
Sleep(z);
}
system("CLS");

}

if(n%20==19){


cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<"               SCORE:"<<n<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<' '<<x<<endl;
cout<<q<<endl;
cout<<m<<endl;
cout<<q<<endl;
cout<<m;
Sleep(y);
if(d=="###" && q==" #"){
system("CLS");
cout<<"                  ________________" <<endl;
cout<<"                  Your Score is :" <<n<<endl;
cout<<"                  ________________"<<endl;
cout<<endl;
cout<<"                !!!!!GAME OVER!!!!!"<<endl;

song();
cout<<" PRESS 0"<<endl;
Sleep(z);
}

if(d=="    ###" && q=="     #"){
system("CLS");
cout<<"                  ________________"<<endl ;
cout<<"                  Your Score is :" <<n<<endl;
cout<<"                  ________________"<<endl;
cout<<endl;
cout<<"                !!!!!GAME OVER!!!!!"<<endl;

song();
cout<<" PRESS 0"<<endl;
Sleep(z);
}
system("CLS");

}

if(n%20==0){


cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<"               SCORE:"<<n<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<"   |"<<endl;
cout<<q<<endl;
cout<<m<<endl;
cout<<q<<endl;
cout<<m;
Sleep(y);
if(d=="###" && q==" #"){
system("CLS");
cout<<"                  ________________"<<endl ;
cout<<"                  Your Score is :" <<n<<endl;
cout<<"                  ________________"<<endl;
cout<<endl;
cout<<"                !!!!!GAME OVER!!!!!"<<endl;

song();
cout<<" PRESS 0"<<endl;
Sleep(z);

}

if(d=="    ###" && q=="     #"){
system("CLS");

cout<<"                  ________________"<<endl ;
cout<<"                   Your Score is :" <<n<<endl;
cout<<"                  ________________"<<endl;
cout<<endl;
cout<<"                !!!!!GAME OVER!!!!!"<<endl;

song();
cout<<" PRESS 0"<<endl;
Sleep(z);
}
system("CLS");

}





n=n+1;

}
if(g=='a'){
m="###";
q=" #";
count=count+1;
if(count==1){n=1;}
}
if(g=='d'){
m="    ###";
q="     #";
count=count+1;
if(count==1){n=1;}
}

}
int ji;
cout<<"          1.RESTRAT THE GAME"<<endl;
cout<<"               2.EXIT"<<endl;
cin>>ji;
if(ji==1){w=w+1;}
if(ji==2){w=-w;}
system("CLS");
w=w+1;
}
return 0;
}

bool getInput(char *c){
if (kbhit()){
*c = getch();
return true;
}
return false;
}



