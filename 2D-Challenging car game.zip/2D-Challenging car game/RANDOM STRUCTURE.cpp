#include <iostream>
#include <conio.h>
#include <stdlib.h>
#include <time.h>
#include <cstring>
using namespace std;
int main(){

int d=0;
int n=1;
while (n>0){
srand ( time(NULL));
int RandIndex = rand() %51;
int a;
int b[50];
int p=0;

for(int i=0;i<50;i++){
   if(b[i]==RandIndex){
   	p++;
   }
   
}
if(p==0){
	b[d]=RandIndex;
	cout<<RandIndex<<",";
	d++;
	if(d==50){
		n=-n;
	}
}		


a=RandIndex;




n=n+1;
            }
            
            

            
        

return 0;
}
