#include <iostream>
#include <conio.h>
using namespace std;



bool getInput(char *c); // Program Loop
int main(void){
	
char y = ' ';
while (y != 'q')
	{ 	
		while (!getInput(&y))
      		{ 
			  cout<<"sd";	
            	}
           
            	cout << "You Pressed: " << y << endl;
               	} 	cout << "You Pressed q, End Of Program" << endl;
                  	return 0; }
                     // Get Input
                     
                     
                     
                     
                     
                     bool getInput(char *c)
                     {
					 
					  if (kbhit())
                     { *c = getch();
                      return true; // Key Was Hit
                      }
                      	return false; // No keys were pressed
                        }	
