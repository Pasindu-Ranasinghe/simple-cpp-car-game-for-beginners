#include <iostream.h>
#include <conio.h>
#include <time.h>
#include <windows.h>
//#include <stdafx>

int main(){

int x=600;
Sleep(x);
cout<<"byg";




getch();
}