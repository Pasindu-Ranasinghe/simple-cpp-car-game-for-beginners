#include <iostream.h>
#include <conio.h>
#include <stdlib.h>
#include <windows.h>

void main(){
char x='#';
char t=' ';
int n=1;
int m=0;
int y=300;
int z=1000;
cout<<' '<<x<<endl;
cout<<x;
cout<<x;
cout<<x<<endl;
cout<<' '<<x;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<' '<<x<<endl;
cout<<x;
cout<<x;
cout<<x<<endl;
cout<<' '<<x;
Sleep(z);
system("CLS");
while (n>0){

if(n%40==0){
y=y-50;
}


if(n%20==1){

cout<<' '<<x<<endl;
cout<<x;
cout<<x;
cout<<x<<endl;
cout<<' '<<x;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<' '<<x<<endl;
cout<<x;
cout<<x;
cout<<x<<endl;
cout<<' '<<x;


Sleep(y);
system("CLS");


}
if(n%20==2){
cout<<endl;
cout<<' '<<x<<endl;
cout<<x;
cout<<x;
cout<<x<<endl;
cout<<' '<<x;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<' '<<x<<endl;
cout<<x;
cout<<x;
cout<<x<<endl;
cout<<' '<<x;
Sleep(y);
system("CLS");

}
if(n%20==3){
cout<<endl;
cout<<endl;
cout<<' '<<x<<endl;
cout<<x;
cout<<x;
cout<<x<<endl;
cout<<' '<<x;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
Sleep(y);
system("CLS");

}

if(n%20==4){
cout<<endl;
cout<<endl;
cout<<endl;
cout<<' '<<x<<endl;
cout<<x;
cout<<x;
cout<<x<<endl;
cout<<' '<<x;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
Sleep(y);
system("CLS");
}

if(n%20==5){
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<' '<<x<<endl;
cout<<x;
cout<<x;
cout<<x<<endl;
cout<<' '<<x;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
Sleep(y);
system("CLS");

}
if(n%20==6){
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<' '<<x<<endl;
cout<<x;
cout<<x;
cout<<x<<endl;
cout<<' '<<x;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
Sleep(y);
system("CLS");

}
if(n%20==7){
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<' '<<x<<endl;
cout<<x;
cout<<x;
cout<<x<<endl;
cout<<' '<<x;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
Sleep(y);
system("CLS");

}
if(n%20==8){
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<' '<<x<<endl;
cout<<x;
cout<<x;
cout<<x<<endl;
cout<<' '<<x;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
Sleep(y);
system("CLS");

}
if(n%20==9){
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<' '<<x<<endl;
cout<<x;
cout<<x;
cout<<x<<endl;
cout<<' '<<x;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
Sleep(y);
system("CLS");

}
if(n%20==10){
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<' '<<x<<endl;
cout<<x;
cout<<x;
cout<<x<<endl;
cout<<' '<<x;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
Sleep(y);
system("CLS");

}
if(n%20==11){
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<' '<<x<<endl;
cout<<x;
cout<<x;
cout<<x<<endl;
cout<<' '<<x;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
Sleep(y);
system("CLS");

}
if(n%20==12){
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<' '<<x<<endl;
cout<<x;
cout<<x;
cout<<x<<endl;
cout<<' '<<x;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
Sleep(y);
system("CLS");

}
if(n%20==13){
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<' '<<x<<endl;
cout<<x;
cout<<x;
cout<<x<<endl;
cout<<' '<<x;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
Sleep(y);
system("CLS");

}
if(n%20==14){

cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<' '<<x<<endl;
cout<<x;
cout<<x;
cout<<x<<endl;
cout<<' '<<x;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;

Sleep(y);
system("CLS");

}
if(n%20==15){


cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<' '<<x<<endl;
cout<<x;
cout<<x;
cout<<x<<endl;
cout<<' '<<x;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
Sleep(y);
system("CLS");

}
if(n%20==16){

cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<' '<<x<<endl;
cout<<x;
cout<<x;
cout<<x<<endl;
cout<<' '<<x;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
Sleep(y);
system("CLS");

}
if(n%20==17){
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<' '<<x<<endl;
cout<<x;
cout<<x;
cout<<x<<endl;
cout<<' '<<x;
cout<<endl;
cout<<endl;
cout<<endl;
Sleep(y);
system("CLS");

}
if(n%20==18){
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<' '<<x<<endl;
cout<<x;
cout<<x;
cout<<x<<endl;
cout<<' '<<x;
cout<<endl;
cout<<endl;
Sleep(y);
system("CLS");

}
if(n%20==19){
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<' '<<x<<endl;
cout<<x;
cout<<x;
cout<<x<<endl;
cout<<' '<<x;
cout<<endl;
Sleep(y);
system("CLS");

}
if(n%20==0){
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<endl;
cout<<' '<<x<<endl;
cout<<x;
cout<<x;
cout<<x<<endl;
cout<<' '<<x;
system("CLS");

}



n=n+1;
}



getch();
}